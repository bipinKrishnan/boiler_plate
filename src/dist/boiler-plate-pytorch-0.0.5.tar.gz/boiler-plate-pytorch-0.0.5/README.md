## boiler-plate

This library aims at replacing boilerplate code that occur while training neural networks using [PyTorch](https://pytorch.org/)
